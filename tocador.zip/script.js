const nomeMusica = document.getElementById("nome-musica");
const song = document.getElementById("audio");
const play = document.getElementById("play/pause");

nomeMusica.innerText = "Retrospective";

function playmusica() {
    song.play()
}

play.addEventListener('click', playMusica);